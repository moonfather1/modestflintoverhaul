package moonfather.modestflintoverhaul.falling_onto_trapdoors;

import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.GravelBlock;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.entity.item.FallingBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class FleetingGravelBlock extends GravelBlock
{
    public FleetingGravelBlock()
    {
        super(Properties.of(Material.SAND, MaterialColor.STONE).strength(0.6F).sound(SoundType.GRAVEL));
    }
    // ignore the name.
    // the thing is, we had two gravel blocks - original and ours. but when original fell onto a torch or a trapdoor, it spawned its item
    //   which wasn't good and i couldn't change it. but when our block fell onto a trapdoor, it spawned nothing because it had no item.
    //   the later i could change using overrides below, but since i need swicharoo for former, i though i add two temporary blocks for clarity.
    // this block falls instead of OUR gravel when it starts falling. it should never appear in world as a block or as an item - only as within FallingBlockEntity.



    @Override
    public void onBroken(World level, BlockPos blockPos, FallingBlockEntity fallingBlockEntity)
    {
        fallingBlockEntity.spawnAtLocation(new ItemStack(RegistryManager.ItemGravelUnsearched.get()));
    }

    @Override
    public void onLand(World level, BlockPos blockPos, BlockState blockState1, BlockState blockState2, FallingBlockEntity fallingBlockEntity)
    {
        level.setBlockAndUpdate(blockPos, Blocks.GRAVEL.defaultBlockState());
    }

    @Override
    public Item asItem()
    {
        return RegistryManager.ItemGravelUnsearched.get();
    }
}
