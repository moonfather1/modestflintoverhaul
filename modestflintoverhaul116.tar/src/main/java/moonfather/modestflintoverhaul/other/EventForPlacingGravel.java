package moonfather.modestflintoverhaul.other;

import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class EventForPlacingGravel
{
    @SubscribeEvent
    public static void OnEntityPlace(PlayerInteractEvent.RightClickBlock event)
    {
        if (event.getItemStack().getItem().equals(Blocks.GRAVEL.asItem()))
        {
            BlockPos destination = event.getPos().relative(event.getFace());
            if (event.getEntity().isCrouching())
            {
                event.setUseItem(Event.Result.DENY);
                event.setUseBlock(Event.Result.DENY);
                event.setCancellationResult(ActionResultType.sidedSuccess(event.getWorld().isClientSide()));
                event.setCanceled(true); // without this we get double use() calls
                if (EventForPlacingGravel.CanPlace(event.getWorld(), destination))       // our thing
                {
                    event.getEntity().level.setBlockAndUpdate(destination, RegistryManager.BlockGravelSearched.get().defaultBlockState());
                    if (!event.getWorld().isClientSide() && !event.getPlayer().isCreative())
                    {
                        event.getItemStack().shrink(1);
                    }
                }
            }
            else
            {
                event.setUseItem(Event.Result.DENY);
                BlockState targetState = event.getWorld().getBlockState(event.getPos());
                ActionResultType result = targetState.getBlock().use(targetState, event.getWorld(), event.getPos(), event.getPlayer(), event.getHand(), event.getHitVec());
                event.setUseBlock(Event.Result.DENY);
                event.setCancellationResult(ActionResultType.sidedSuccess(event.getWorld().isClientSide()));
                event.setCanceled(true); // without this we get double use() calls
                if (result.equals(ActionResultType.PASS))     // our thing
                {
                    if (EventForPlacingGravel.CanPlace(event.getWorld(), destination))
                    {
                        event.getPlayer().level.setBlockAndUpdate(destination, RegistryManager.BlockGravelSearched.get().defaultBlockState());
                        if (!event.getWorld().isClientSide() && ! event.getPlayer().isCreative())
                        {
                            event.getItemStack().shrink(1);
                        }
                        event.setCanceled(true);
                    }
                }
            }
        }
    }



    private static boolean CanPlace(World level, BlockPos pos)
    {
        BlockState state = Blocks.GRAVEL.defaultBlockState();
        return (state.canSurvive(level, pos)) && level.getBlockState(pos).getMaterial().isReplaceable();
    }
}