package moonfather.modestflintoverhaul.items;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.GravelBlock;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.material.MaterialColor;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;

public class OurGravelBlock extends GravelBlock
{
    public OurGravelBlock()
    {
        super(Properties.of(Material.SAND, MaterialColor.STONE).strength(0.6F).sound(SoundType.GRAVEL));
    }



    public static Item.Properties GetItemProperties()
    {
        return new Item.Properties().tab(ItemGroup.TAB_BUILDING_BLOCKS);
    }



    @Override
    public ItemStack getCloneItemStack(IBlockReader world, BlockPos blockPos, BlockState blockState)
    {
        return Blocks.GRAVEL.asItem().getDefaultInstance();
    }
}
