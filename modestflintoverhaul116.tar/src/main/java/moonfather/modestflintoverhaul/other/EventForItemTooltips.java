package moonfather.modestflintoverhaul.other;

import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.Blocks;
import net.minecraft.util.text.*;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class EventForItemTooltips
{
    @SubscribeEvent
    public static void OnItemTooltip(ItemTooltipEvent event)
    {
        if (!event.getItemStack().isEmpty() && event.getItemStack().getItem().equals(Blocks.GRAVEL.asItem()))
        {
            event.getToolTip().add(wontHaveFlint1);
            event.getToolTip().add(wontHaveFlint2);
        }
        if (!event.getItemStack().isEmpty() && event.getItemStack().getItem().equals(RegistryManager.ItemGravelUnsearched.get()))
        {
            event.getToolTip().add(mayHaveFlint1);
            event.getToolTip().add(mayHaveFlint2);
        }
    }

    private static final ITextComponent mayHaveFlint1 = new TranslationTextComponent("item.modestflintoverhaul.gravel_unsearched.tooltip1").withStyle(Style.EMPTY.withColor(Color.fromRgb(0x9e7b4d)));
    private static final ITextComponent mayHaveFlint2 = new TranslationTextComponent("item.modestflintoverhaul.gravel_unsearched.tooltip2").withStyle(Style.EMPTY.withColor(Color.fromRgb(0x9e7b4d)));
    private static final ITextComponent wontHaveFlint1 = new TranslationTextComponent("item.modestflintoverhaul.gravel_searched.tooltip1").withStyle(Style.EMPTY.withColor(Color.fromRgb(0x9e7b4d)));
    private static final ITextComponent wontHaveFlint2 = new TranslationTextComponent("item.modestflintoverhaul.gravel_searched.tooltip2").withStyle(Style.EMPTY.withColor(Color.fromRgb(0x9e7b4d)));
}