package moonfather.modestflintoverhaul.falling_onto_trapdoors;

import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.Blocks;
import net.minecraft.entity.item.FallingBlockEntity;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class EventForFixingFallingBlocks {
    @SubscribeEvent
    public static void OnEntityJoinLevel(EntityJoinWorldEvent event)
    {
        if (event.getEntity() instanceof FallingBlockEntity)
        {
            FallingBlockEntity fbe = (FallingBlockEntity) event.getEntity();
            if (fbe.blockState.is(Blocks.GRAVEL))
            {
                fbe.blockState = RegistryManager.BlockGravelFleeting.get().defaultBlockState();
                if (fbe.level.getBlockState(fbe.blockPosition()).is(Blocks.GRAVEL))
                {
                    fbe.level.setBlock(fbe.blockPosition(), fbe.blockState, 2);
                }
            }
            else if (fbe.blockState.is(RegistryManager.BlockGravelSearched.get()))
            {
                fbe.blockState = RegistryManager.BlockGravelElusive.get().defaultBlockState();
                if (fbe.level.getBlockState(fbe.blockPosition()).is(RegistryManager.BlockGravelSearched.get()))
                {
                    fbe.level.setBlock(fbe.blockPosition(), fbe.blockState, 2);
                }
            }
        }
    }
}
