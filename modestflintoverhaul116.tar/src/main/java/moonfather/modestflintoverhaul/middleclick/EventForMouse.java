package moonfather.modestflintoverhaul.middleclick;

import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(Dist.CLIENT)
public class EventForMouse
{
    @SubscribeEvent
    public static void OnClickInput(InputEvent.ClickInputEvent event)
    {
        if (event.isPickBlock())
        {
            RayTraceResult target = Minecraft.getInstance().hitResult;
            if (target != null && target.getType() == RayTraceResult.Type.BLOCK)
            {
                BlockPos pos = ((BlockRayTraceResult) target).getBlockPos();
                BlockState state = Minecraft.getInstance().level.getBlockState(pos);
                if (state.is(Blocks.GRAVEL))
                {
                    event.setCanceled(true);
                    /////////
                    ClientPlayerEntity player = Minecraft.getInstance().player;
                    ItemStack result = new ItemStack(RegistryManager.ItemGravelUnsearched.get());
                    if (player.abilities.instabuild)
                    {
                        player.inventory.setPickedItem(result);
                        Minecraft.getInstance().gameMode.handleCreativeModeItemAdd(player.getItemInHand(Hand.MAIN_HAND), 36 + player.inventory.selected);
                        //return true;
                    }
                    int slot = player.inventory.findSlotMatchingItem(result);
                    if (slot != -1)
                    {
                        if (PlayerInventory.isHotbarSlot(slot))
                            player.inventory.selected = slot;
                        else
                            Minecraft.getInstance().gameMode.handlePickItem(slot);
                        //return true;
                    }
                    //return false;
                    /////////
                }
            }
        }
    }
}
