package moonfather.modestflintoverhaul.items;

import net.minecraft.block.Block;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TranslationTextComponent;
import net.minecraft.world.World;

import javax.annotation.Nullable;
import java.util.List;

public class BlockItemEx extends BlockItem
{
    public static BlockItemEx Create(Block block, Item.Properties properties)
    {
        return new BlockItemEx(block, properties);
    }

    private BlockItemEx(Block block, Item.Properties properties)
    {
        super(block, properties);
    }

    private TranslationTextComponent line1 = null, line2 = null;
    public BlockItemEx AppendTooltipLine(TranslationTextComponent line)
    {
        if (this.line1 == null)
        {
            this.line1 = line;
        }
        else if (this.line2 == null)
        {
            this.line2 = line;
        }
        return this;
    }

    @Override
    public void appendHoverText(ItemStack itemStack, @Nullable World world, List<ITextComponent> lines, ITooltipFlag flags)
    {
        super.appendHoverText(itemStack, world, lines, flags);
        if (line1 != null)
        {
            lines.add(line1);
            if (line2 != null)
            {
                lines.add(line2);
            }
        }
    }
}
