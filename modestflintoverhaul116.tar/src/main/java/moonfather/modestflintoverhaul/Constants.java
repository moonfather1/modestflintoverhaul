package moonfather.modestflintoverhaul; 
 
public class Constants 
{ 
    public static final String MODID = "modestflintoverhaul"; 
} 
