package moonfather.modestflintoverhaul.other;

import moonfather.modestflintoverhaul.OptionsHolder;
import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DispenserBlock;
import net.minecraft.dispenser.IBlockSource;
import net.minecraft.dispenser.OptionalDispenseBehavior;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import javax.annotation.Nonnull;

public class GravelDispenseBehavior extends OptionalDispenseBehavior
{
    public static void Init()
    {
        DispenserBlock.registerBehavior(Items.GRAVEL, new GravelDispenseBehavior(RegistryManager.BlockGravelSearched.get()));
        DispenserBlock.registerBehavior(RegistryManager.ItemGravelUnsearched.get(), new GravelDispenseBehavior(Blocks.GRAVEL));
    }

    private final Block blockToPlace;
    public GravelDispenseBehavior(Block blockToPlace)
    {
        this.blockToPlace = blockToPlace;
    }

    @Override
    protected @Nonnull ItemStack execute(IBlockSource source, ItemStack stack)
    {
        if (! OptionsHolder.ShouldDispenseBlocks())
        {
            return super.execute(source, stack);
        }
        World level = source.getLevel();
        BlockPos pos = source.getPos().relative(source.getBlockState().getValue(DispenserBlock.FACING));
        BlockState state = level.getBlockState(pos);
        if (state.isAir() || state.getMaterial().isReplaceable())
        {
            this.setSuccess(true);
            level.setBlockAndUpdate(pos, this.blockToPlace.defaultBlockState());
            stack.shrink(1);
            return stack;
        }
        else
        {
            this.setSuccess(false);
            return stack;
        }
    }
}
