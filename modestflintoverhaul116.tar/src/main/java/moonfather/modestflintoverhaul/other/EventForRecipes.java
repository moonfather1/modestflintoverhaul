package moonfather.modestflintoverhaul.other;

import moonfather.modestflintoverhaul.RegistryManager;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.ICraftingRecipe;
import net.minecraft.item.crafting.IRecipeType;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.profiler.IProfiler;
import net.minecraft.resources.IFutureReloadListener;
import net.minecraft.resources.IResourceManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.tags.ITag;
import net.minecraft.tags.ItemTags;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.server.FMLServerStartingEvent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;

import java.util.List;
import java.util.ListIterator;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

@Mod.EventBusSubscriber
public class EventForRecipes
{
    public static final ITag<Item> GravelTag = ItemTags.bind("forge:gravel");

    @SubscribeEvent
    public static void OnServerStarting(FMLServerStartingEvent event)
    {
        ReplaceGravelInRecipes(event.getServer());
    }

    private static void ReplaceGravelInRecipes(MinecraftServer server)
    {
        ItemStack vanillaGravel = new ItemStack(Blocks.GRAVEL);
        ItemStack ourGravel = new ItemStack(RegistryManager.ItemGravelUnsearched.get());
        List<ICraftingRecipe> list = server.getRecipeManager().getAllRecipesFor(IRecipeType.CRAFTING);
        for (ICraftingRecipe recipe : list)
        {
            ListIterator<Ingredient> i = recipe.getIngredients().listIterator();
            while (i.hasNext())
            {
                Ingredient ingredient = i.next();
                if (ingredient.test(vanillaGravel) && ! ingredient.test(ourGravel))
                {
                    i.set(Ingredient.of(GravelTag));
                }
            }
        }
    }

    //-----------------------------------

    @SubscribeEvent
    public static void OnAddReloadListener(AddReloadListenerEvent event)
    {
        for (IFutureReloadListener listener: event.getListeners())
        {
            if (listener instanceof ReloadListener)
            {
                return;
            }
        }
        event.addListener(lissy);
    }

    private static final IFutureReloadListener lissy = new ReloadListener();

    private static class ReloadListener implements IFutureReloadListener
    {
        @Override
        public CompletableFuture<Void> reload(IStage p_10638_, IResourceManager p_10639_, IProfiler p_10640_, IProfiler p_10641_, Executor p_10642_, Executor p_10643_)
        {
            if (ServerLifecycleHooks.getCurrentServer() != null) // will be null one during load
            {
                ReplaceGravelInRecipes(ServerLifecycleHooks.getCurrentServer());
            }
            return p_10638_.wait(null);
        }
    }
}