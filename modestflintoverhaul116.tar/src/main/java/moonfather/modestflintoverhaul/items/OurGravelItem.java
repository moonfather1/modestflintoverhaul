package moonfather.modestflintoverhaul.items;

import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.SoundType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.item.*;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.world.World;

import javax.annotation.Nullable;

public class OurGravelItem extends Item
{
	public OurGravelItem()
	{
		super(OurGravelItem.GetProperties());
	}

	private static Properties GetProperties()
	{
		Properties properties = new Properties();
		properties.tab(ItemGroup.TAB_BUILDING_BLOCKS);
		return properties;
	}


	@Override
	public ActionResultType useOn(ItemUseContext context)
	{
		BlockItemUseContext blockitemusecontext = new BlockItemUseContext(context);


		if (! blockitemusecontext.canPlace()) {
			return ActionResultType.FAIL;
		} else {
			BlockState blockstate = this.getPlacementState(blockitemusecontext);
			if (blockstate == null) {
				return ActionResultType.FAIL;
			} else if (!this.placeBlock(blockitemusecontext, blockstate)) {
				return ActionResultType.FAIL;
			} else {
				BlockPos blockpos = blockitemusecontext.getClickedPos();
				World world = blockitemusecontext.getLevel();
				PlayerEntity playerentity = blockitemusecontext.getPlayer();
				ItemStack itemstack = blockitemusecontext.getItemInHand();
				BlockState blockstate1 = world.getBlockState(blockpos);
				Block block = blockstate1.getBlock();
				if (block.is(blockstate.getBlock())) {
					block.setPlacedBy(world, blockpos, blockstate1, playerentity, itemstack);
					if (playerentity instanceof ServerPlayerEntity) {
						CriteriaTriggers.PLACED_BLOCK.trigger((ServerPlayerEntity)playerentity, blockpos, itemstack);
					}
				}

				SoundType soundtype = blockstate1.getSoundType(world, blockpos, context.getPlayer());
				world.playSound(playerentity, blockpos, this.getPlaceSound(blockstate1), SoundCategory.BLOCKS, (soundtype.getVolume() + 1.0F) / 2.0F, soundtype.getPitch() * 0.8F);
				if (playerentity == null || !playerentity.abilities.instabuild) {
					itemstack.shrink(1);
				}

				return ActionResultType.sidedSuccess(world.isClientSide);
			}
		}
	}

	@Nullable
	protected BlockState getPlacementState(BlockItemUseContext p_40613_) {
		BlockState blockstate = Blocks.GRAVEL.getStateForPlacement(p_40613_);
		return blockstate != null && this.canPlace(p_40613_, blockstate) ? blockstate : null;
	}

	protected boolean canPlace(BlockItemUseContext context, BlockState blockState) {
		PlayerEntity playerentity = context.getPlayer();
		ISelectionContext iselectioncontext = playerentity == null ? ISelectionContext.empty() : ISelectionContext.of(playerentity);
		return (blockState.canSurvive(context.getLevel(), context.getClickedPos())) && context.getLevel().isUnobstructed(blockState, context.getClickedPos(), iselectioncontext);
	}

	private SoundEvent getPlaceSound(BlockState blockstate1)
	{
		return Blocks.GRAVEL.getSoundType(blockstate1).getPlaceSound();
	}


	protected boolean placeBlock(BlockItemUseContext p_40578_, BlockState p_40579_) {
		return p_40578_.getLevel().setBlock(p_40578_.getClickedPos(), p_40579_, 11);
	}
}
